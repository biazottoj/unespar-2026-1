/**
 * 
 */
/**
 * 
 */
module SistemaHotel {
}