package model;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
	public List<Quarto> quartos;
	
	public Hotel() {
		this.quartos = new ArrayList<Quarto>();
	}

	public List<Quarto> getQuartos() {
		return quartos;
	}	
	
}
