package model;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
	private List<Quarto> quartos;
	
	public Hotel() {
		this.quartos = new ArrayList<Quarto>();
	}

	public List<Quarto> getQuartos() {
		return quartos;
	}	
	
	public void adicionarQuarto(int numero, 
								double valorDiaria,
								Tipo tipo,
								Disponibilidade disponibilidade) {
	
		Quarto quarto = new Quarto(numero,
								   valorDiaria,
								   tipo,
								   disponibilidade);
		this.quartos.add(quarto);
	}
	
	public void adicionarQuarto(Quarto quarto) {
		this.quartos.add(quarto);
	}
}
