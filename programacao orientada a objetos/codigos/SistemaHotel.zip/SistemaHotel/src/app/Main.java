package app;

import model.Disponibilidade;
import model.Hotel;
import model.Quarto;
import model.Tipo;

public class Main {

	public static void main(String[] args) {
		Quarto q1 = new Quarto(101, 120.0, Tipo.SIMPLES, Disponibilidade.DISPONIVEL);
		Quarto q2 = new Quarto(102, 180.0, Tipo.DUPLO, Disponibilidade.OCUPADO);
		Quarto q3 = new Quarto(103, 500.0, Tipo.COBERTURA, Disponibilidade.DISPONIVEL);
		
		Hotel hotel = new Hotel();
		
		hotel.quartos.add(q1);
		hotel.quartos.add(q2);
		hotel.quartos.add(q3);
		
		for(Quarto q : hotel.quartos) {
			if(q.getDisponibilidade() 
					== Disponibilidade.DISPONIVEL) {
				System.out.println("Quarto " 
					+ q.getNumero() + " disponível!");
			}
		}
		
	}

}
