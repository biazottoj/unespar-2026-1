package app;

import model.Disponibilidade;
import model.Hotel;
import model.Quarto;
import model.Tipo;
import utils.ComparadorPorPreco;

public class Main {

	public static void main(String[] args) {
		Quarto q1 = new Quarto(101, 180.0, Tipo.SIMPLES, Disponibilidade.DISPONIVEL);
		Quarto q2 = new Quarto(102, 110.0, Tipo.DUPLO, Disponibilidade.OCUPADO);
		Quarto q3 = new Quarto(103, 500.0, Tipo.COBERTURA, Disponibilidade.DISPONIVEL);
		
		Hotel hotel = new Hotel();
		
		hotel.adicionarQuarto(q1);
		hotel.adicionarQuarto(q2);
		hotel.adicionarQuarto(q3);
		

		
		hotel.getQuartos().sort((judas, tome) -> 
							Double.compare(judas.getValorDiaria(), 
									tome.getValorDiaria()));
		for(Quarto q : hotel.getQuartos()) {
			System.out.println(q.getValorDiaria());
		}
		
	}

}
