package entidade;

public class Livro extends ItemBiblioteca {
	private String autor;

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	@Override
	public void exibirDetalhes() {
		System.out.println(this.getTitulo() + " - " + this.getAutor());
	}
}
