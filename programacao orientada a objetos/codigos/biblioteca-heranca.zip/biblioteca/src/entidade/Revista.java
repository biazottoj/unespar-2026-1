package entidade;

public class Revista extends ItemBiblioteca{
	
	private String editor;
	private String mesPublicacao;
	public String getEditor() {
		return editor;
	}
	public void setEditor(String editor) {
		this.editor = editor;
	}
	public String getMesPublicacao() {
		return mesPublicacao;
	}
	public void setMesPublicacao(String mesPublicacao) {
		this.mesPublicacao = mesPublicacao;
	}
	
	@Override
	public void exibirDetalhes() {
		System.out.println(this.getTitulo() + " - " + this.getMesPublicacao());
	}
	
}
