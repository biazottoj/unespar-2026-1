package entidade;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {

	private List<ItemBiblioteca> items;
	private List<Usuario> usuarios;
	
	public Biblioteca() {
		this.items = new ArrayList<ItemBiblioteca>();
		this.usuarios = new ArrayList<Usuario>();
	}
	
	 public void addItem(ItemBiblioteca item) {
		 this.items.add(item);
	 }
	 
	 
	public void listarItems() {
		for(ItemBiblioteca item : this.items) {
			item.exibirDetalhes();
		}
	}
	
	
}
