package core;

import entidade.Biblioteca;
import entidade.Livro;
import entidade.Revista;
import entidade.Usuario;

public class Main {

	public static void main(String[] args) {
		Revista revista = new Revista();
		Livro livro = new Livro();
		Biblioteca biblioteca = new Biblioteca();
		
		revista.setTitulo("Placar");
		revista.setEditora("Editora Abril");
		revista.setMesPublicacao("abril/2026");
		
		livro.setTitulo("Harry Potter e as Relíquias da Morte");
		livro.setEditora("Rocco");
		livro.setAutor("J. K. Rowling");
				
		biblioteca.addItem(livro);
		biblioteca.addItem(revista);
		
		biblioteca.listarItems();

	}

}
