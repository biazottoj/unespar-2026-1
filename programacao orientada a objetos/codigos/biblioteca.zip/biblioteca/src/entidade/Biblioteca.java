package entidade;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {

	private List<Livro> livros;
	private List<Usuario> usuarios;
	
	public Biblioteca() {
		this.livros = new ArrayList<Livro>();
		this.usuarios = new ArrayList<Usuario>();
	}
	
	
	// add livro
	 public void addLivro(Livro livro) {
		 this.livros.add(livro);
	 }
	 
	 
	// listar
	public void listarLivros() {
		for(Livro livro : this.livros) {
			System.out.println(livro.getTitulo());
		}
	}
	
}
