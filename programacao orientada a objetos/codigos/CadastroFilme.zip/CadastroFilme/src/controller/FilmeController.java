package controller;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import model.Filme;
import repository.FilmeRepository;
import view.FilmeView;

public class FilmeController {
	private FilmeView view;
	private FilmeRepository repository;

	public FilmeController(FilmeView view, FilmeRepository repository) {
		this.view = view;
		this.repository = repository;
		configurarEventos();
	}
	
	
	public void configurarEventos() {
		this.view.getSalvarButton()
		.addActionListener(e -> salvarFilme());
		
		this.view.getNovoButton()
		.addActionListener(e -> novoFilme());
		
		this.view.getExcluirButton()
		.addActionListener(e -> excluirFilme());
		
		this.view.getFilmesTable()
		.getSelectionModel().addListSelectionListener(
			new ListSelectionListener() {
				
				@Override
				public void valueChanged(ListSelectionEvent e) {
					carregarFilmeSelecionado();
				}
			}
		);
		
	}
	
	public void carregarFilmeSelecionado() {
		int linhaSelecionada = view.getFilmesTable().getSelectedRow();
		
		if(linhaSelecionada == -1) {
			return;
		}
		
		view.getExcluirButton().setEnabled(true);		
		int linhaModelo = view.getFilmesTable().convertRowIndexToModel(linhaSelecionada);
		Integer id = (Integer) view.getFilmesTableModel().getValueAt(linhaModelo, 0);
	
		this.repository.buscarPorId(id)
		.ifPresent(this::preencherCampos);
	}
	
	public void preencherCampos(Filme filme) {
		view.getTituloTextField()
		.setText(filme.getTitulo());
		
		view.getGeneroTextField()
		.setText(filme.getGenero());
		
		view.getDuracaoSpinner()
		.setValue(filme.getDuracao());
		
		view.getIdTextField()
		.setText(filme.getId().toString());
	}
	
	
	public void salvarFilme() {
		String titulo = view.getTituloTextField().getText();
		String genero = view.getGeneroTextField().getText();
		Integer duracao = (Integer) view.getDuracaoSpinner()
				.getValue();
		String id = view.getIdTextField().getText();
				
		if(titulo.isBlank()) {
			System.out.println("Título inválido!");
			return;
		}
		
		if(genero.isBlank()) {
			System.out.println("Gênero inválido!");
			return;
		}
		
		Filme filme = new Filme();
		filme.setTitulo(titulo);
		filme.setGenero(genero);
		filme.setDuracao(duracao);
		
		if(id.equals("")) {
			repository.adcionar(filme);
		} else {
			filme.setId(Integer.parseInt(id));
			repository.atualizar(filme);
		}
		
		limparCampos();
		
		montarTabela();
		
	}
	
	public void limparCampos() {
		this.view.getTituloTextField().setText("");
		this.view.getGeneroTextField().setText("");
		this.view.getDuracaoSpinner().setValue(1);
		this.view.getIdTextField().setText("");
		this.view.getExcluirButton().setEnabled(false);
	
	}
	
	public void montarTabela(){
		view.getFilmesTableModel().setRowCount(0);
		
		for(Filme f : repository.listarTodos()) {
			view.getFilmesTableModel().addRow(
					new Object[] {f.getId(),
							f.getTitulo(),
							f.getGenero(),
							f.getDuracao()});
		} 
	}
	
	public void novoFilme() {
		limparCampos();
	}
	
	public void excluirFilme() {
		String id = view.getIdTextField().getText();
		
		repository.excluir(Integer.parseInt(id));
		
		limparCampos();
		montarTabela();
	}
	
}
