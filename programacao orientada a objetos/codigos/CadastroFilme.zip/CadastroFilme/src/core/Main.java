package core;

import controller.FilmeController;
import repository.FilmeRepository;
import view.FilmeView;
import view.TelaPrincipal;

public class Main {

	public static void main(String[] args) {
		TelaPrincipal view = new TelaPrincipal();
		view.setVisible(true);
	}

}
