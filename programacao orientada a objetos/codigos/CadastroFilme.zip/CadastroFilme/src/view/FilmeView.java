package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class FilmeView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel tituloPaginaLabel;
	private JTextField tituloTextField;
	private JTextField generoTextField;
	private JSpinner duracaoSpinner;
	private JButton novoButton;
	private JButton salvarButton;
	private JButton excluirButton;
	
	private JTable filmesTable;
	private DefaultTableModel filmesTableModel;
	private JLabel lblNewLabel_3;
	private JTextField idTextField;

	public DefaultTableModel getFilmesTableModel() {
		return filmesTableModel;
	}

	public void setFilmesTableModel(DefaultTableModel filmesTableModel) {
		this.filmesTableModel = filmesTableModel;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FilmeView frame = new FilmeView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FilmeView() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		tituloPaginaLabel = new JLabel("Cadastro de Filme");
		tituloPaginaLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		tituloPaginaLabel.setBounds(125, 11, 202, 25);
		contentPane.add(tituloPaginaLabel);
		
		JLabel lblNewLabel = new JLabel("Título");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(10, 96, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Gênero");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(10, 121, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Duração");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(10, 146, 59, 14);
		contentPane.add(lblNewLabel_2);
		
		tituloTextField = new JTextField();
		tituloTextField.setBounds(70, 94, 163, 20);
		contentPane.add(tituloTextField);
		tituloTextField.setColumns(10);
		
		generoTextField = new JTextField();
		generoTextField.setBounds(70, 119, 163, 20);
		contentPane.add(generoTextField);
		generoTextField.setColumns(10);
		
		duracaoSpinner = new JSpinner();
		duracaoSpinner.setModel(new SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
		duracaoSpinner.setBounds(70, 144, 46, 20);
		contentPane.add(duracaoSpinner);
		
		novoButton = new JButton("Novo");
		novoButton.setBounds(10, 171, 89, 23);
		contentPane.add(novoButton);
		
		salvarButton = new JButton("Salvar");
		salvarButton.setBounds(109, 171, 89, 23);
		contentPane.add(salvarButton);
		
		excluirButton = new JButton("Excluir");
		excluirButton.setBounds(205, 171, 89, 23);
		excluirButton.setEnabled(false);
		contentPane.add(excluirButton);
		
		filmesTableModel = new DefaultTableModel(new Object[]{"ID", "Título", "Gênero", "Duração"}, 0);
		
		lblNewLabel_3 = new JLabel("ID");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(10, 71, 46, 14);
		contentPane.add(lblNewLabel_3);
		
		idTextField = new JTextField();
		idTextField.setEnabled(false);
		idTextField.setEditable(false);
		idTextField.setBounds(70, 69, 31, 20);
		contentPane.add(idTextField);
		idTextField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 205, 414, 45);
		contentPane.add(scrollPane);
		
		filmesTable = new JTable(filmesTableModel);
		filmesTable.setFont(new Font("Tahoma", Font.PLAIN, 11));
		scrollPane.setViewportView(filmesTable);
		
		filmesTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

	}

	public JTextField getTituloTextField() {
		return tituloTextField;
	}

	public void setTituloTextField(JTextField tituloTextField) {
		this.tituloTextField = tituloTextField;
	}

	public JTextField getGeneroTextField() {
		return generoTextField;
	}

	public void setGeneroTextField(JTextField generoTextField) {
		this.generoTextField = generoTextField;
	}

	public JSpinner getDuracaoSpinner() {
		return duracaoSpinner;
	}

	public void setDuracaoSpinner(JSpinner duracaoSpinner) {
		this.duracaoSpinner = duracaoSpinner;
	}

	public JTable getFilmesTable() {
		return filmesTable;
	}

	public void setFilmesTable(JTable filmesTable) {
		this.filmesTable = filmesTable;
	}

	public JButton getNovoButton() {
		return novoButton;
	}

	public void setNovoButton(JButton novoButton) {
		this.novoButton = novoButton;
	}

	public JButton getSalvarButton() {
		return salvarButton;
	}

	public void setSalvarButton(JButton salvarButton) {
		this.salvarButton = salvarButton;
	}

	public JButton getExcluirButton() {
		return excluirButton;
	}

	public void setExcluirButton(JButton excluirButton) {
		this.excluirButton = excluirButton;
	}

	public JTextField getIdTextField() {
		return idTextField;
	}

	public void setIdTextField(JTextField idTextField) {
		this.idTextField = idTextField;
	}
}
