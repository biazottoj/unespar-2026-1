package strategies;

import model.Pedido;
import utils.FreteStrategy;

public class FreteRetirada implements FreteStrategy{

	@Override
	public double calcular(Pedido pedido) {
		return 0;
	}
	
	

}
