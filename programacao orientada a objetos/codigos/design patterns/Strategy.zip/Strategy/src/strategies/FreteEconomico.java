package strategies;

import model.Pedido;
import utils.FreteStrategy;

public class FreteEconomico implements FreteStrategy{

	@Override
	public double calcular(Pedido pedido) {
		return pedido.getPeso() * 3.00;
	}

}
