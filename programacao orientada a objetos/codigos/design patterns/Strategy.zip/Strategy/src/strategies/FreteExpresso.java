package strategies;

import model.Pedido;
import utils.FreteStrategy;

public class FreteExpresso implements FreteStrategy{

	@Override
	public double calcular(Pedido pedido) {
		return pedido.getPeso() * 12.00 + 15.00;
	}

}
