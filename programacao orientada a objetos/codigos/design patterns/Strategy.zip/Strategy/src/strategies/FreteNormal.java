package strategies;

import model.Pedido;
import utils.FreteStrategy;

public class FreteNormal implements FreteStrategy{

	@Override
	public double calcular(Pedido pedido) {
		return pedido.getPeso() * 5.00;	
	}

}
