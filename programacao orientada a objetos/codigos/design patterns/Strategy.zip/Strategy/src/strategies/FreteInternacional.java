package strategies;

import model.Pedido;
import utils.FreteStrategy;

public class FreteInternacional implements FreteStrategy{

	@Override
	public double calcular(Pedido pedido) {
		return pedido.getPeso() * 20 + 150;
	}

}
