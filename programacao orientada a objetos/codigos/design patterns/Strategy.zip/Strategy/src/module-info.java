/**
 * 
 */
/**
 * 
 */
module Strategy {
}