package app;

import java.util.Calendar;

import model.Pedido;
import strategies.FreteEconomico;
import strategies.FreteExpresso;
import strategies.FreteInternacional;
import strategies.FreteNormal;
import utils.CalculadoraFrete;
import utils.FreteStrategy;

public class Main {

	public static void main(String[] args) {
		
		Pedido pedido = new Pedido();
		pedido.setPeso(5);
		
		FreteStrategy modalidade = new FreteEconomico();
		
		CalculadoraFrete calculadora = new CalculadoraFrete(modalidade);
		
		System.out.println(calculadora.calcular(pedido));
	}

}
