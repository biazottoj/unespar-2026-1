package utils;

import model.Pedido;

public interface FreteStrategy {
	
	public double calcular(Pedido pedido);

}
