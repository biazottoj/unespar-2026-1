package utils;

import model.Pedido;

public class CalculadoraFrete {
	
	private double cupomDesconto = 0;
	
	private FreteStrategy modalidadeEntrega;

	public CalculadoraFrete(FreteStrategy modalidadeEntrega) {
		this.modalidadeEntrega = modalidadeEntrega;
	}
	
	public double calcular(Pedido pedido) {
		return modalidadeEntrega.calcular(pedido) - cupomDesconto;
	}
	
}
