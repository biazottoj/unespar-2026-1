package app;

import utils.Configuracoes;
import utils.GerenciadorLog;

public class TelaConfiguracao {
	
	public void alterarTema() {
		GerenciadorLog.INSTANCE.addLog("Alterando tema do sistema");
		Configuracoes.getInstance().setTema("Escuro");
	}
	
}
