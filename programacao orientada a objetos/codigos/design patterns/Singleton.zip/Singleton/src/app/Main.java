package app;

import utils.Configuracoes;
import utils.GerenciadorLog;
import utils.Singleton;

public class Main {

	public static void main(String[] args) {
		
		GerenciadorLog.INSTANCE.addLog("Iniciando o sistema");
		
		System.out.println(Configuracoes.getInstance().getTema());
		TelaConfiguracao tc = new TelaConfiguracao();
		
		tc.alterarTema();
		
		GerenciadorLog.INSTANCE.addLog("Finalizando Execucao");
		
		GerenciadorLog.INSTANCE.listarLogs();
		
	}
	
}
