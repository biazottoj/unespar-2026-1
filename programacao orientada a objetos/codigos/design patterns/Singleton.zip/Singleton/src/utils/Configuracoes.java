package utils;

public class Configuracoes {
	
	private static Configuracoes instance;
	private String caminhoLog;
	private int tamanhoFonte;
	private String tema;
		
	private Configuracoes() {}
	
	public static Configuracoes getInstance() {
		if(instance == null) {
			instance = new Configuracoes();
		}
		
		return instance;
		
	}

	public String getCaminhoLog() {
		return caminhoLog;
	}

	public void setCaminhoLog(String caminhoLog) {
		this.caminhoLog = caminhoLog;
	}

	public int getTamanhoFonte() {
		return tamanhoFonte;
	}

	public void setTamanhoFonte(int tamanhoFonte) {
		this.tamanhoFonte = tamanhoFonte;
	}

	public String getTema() {
		return tema;
	}

	public void setTema(String tema) {
		this.tema = tema;
	}
	
	
	
}
