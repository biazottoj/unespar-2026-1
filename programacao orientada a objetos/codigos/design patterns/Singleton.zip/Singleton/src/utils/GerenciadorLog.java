package utils;

import java.util.List;
import java.util.ArrayList;

// Guardar os logs do sistema
public enum GerenciadorLog {
	INSTANCE;
	
	private List<String> logs = new ArrayList<String>();
	
	public void addLog(String log) {
		this.logs.add(log);
	}
	
	public void listarLogs(){
		for(String s : this.logs) {
			System.out.println(s);
		}
	};
	
	
}
