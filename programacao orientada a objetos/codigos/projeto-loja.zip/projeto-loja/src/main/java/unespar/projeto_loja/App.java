package unespar.projeto_loja;

import java.sql.Connection;
import java.sql.SQLException;

public class App 
{
    public static void main( String[] args ) throws SQLException
    {
    	ProdutoDAO dao = new ProdutoDAO();    	
        try {
			Produto p = dao.buscarPorId(7);
			
			if(p != null) {
				System.out.println(p.getId());
				System.out.println(p.getDescricao());
				System.out.println(p.getPreco());
			} else {
				System.out.println("Produto não encontrado!");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
    }
}
