package model;

public class Moto extends Veiculo{

	public Moto(String placa, String modelo) {
		super(placa, modelo);
	}

	@Override
	public double calcularPedagio() {
		return 6.25;
	}

}
