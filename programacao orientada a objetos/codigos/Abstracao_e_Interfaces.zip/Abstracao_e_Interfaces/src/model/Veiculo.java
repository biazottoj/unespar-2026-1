package model;

public abstract class Veiculo {

	private final String placa;
	private String modelo;
	
	
	public Veiculo(String placa, String modelo) {
		this.placa = placa;
		this.modelo = modelo;
	}
	
	public String getPlaca() {
		return placa;
	}

	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	public abstract double calcularPedagio();
	
	public final void getResumo() {
		System.out.println(this.placa + " " + this.modelo);
	}
	
}
