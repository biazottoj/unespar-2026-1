package model;

import interfaces.Rastreavel;
import interfaces.Tributavel;

public class Caminhao extends Veiculo 
				implements Rastreavel, Tributavel{
	private int qtdEixos;

	public Caminhao(String placa, String modelo, 
			int qtdEixos) {
		super(placa, modelo);
		this.qtdEixos = qtdEixos;
	}

	public int getQtdEixos() {
		return qtdEixos;
	}

	public void setQtdEixos(int qtdEixos) {
		this.qtdEixos = qtdEixos;
	}

	@Override
	public double calcularPedagio() {
		return qtdEixos * 9.5;
	}

	@Override
	public double getValorImposto() {
		return 200.0;
	}

	@Override
	public String getPosicaoAtual() {
		return "-23.571935, -51.424905" ;
	}
	
	

	
}
