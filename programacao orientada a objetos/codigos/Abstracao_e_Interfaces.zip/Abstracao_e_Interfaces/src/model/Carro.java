package model;

public class Carro extends Veiculo {

	public Carro(String placa, String modelo) {
		super(placa, modelo);
	}

	@Override
	public double calcularPedagio() {
		return 9.90;
	}

	
	
}
