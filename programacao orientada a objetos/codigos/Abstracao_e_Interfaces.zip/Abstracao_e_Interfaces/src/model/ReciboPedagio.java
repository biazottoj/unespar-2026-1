package model;

import java.time.LocalDate;

public final class ReciboPedagio {
	
	private final String identificacaoVeiculo;
	private final double valor;
	private final LocalDate data;
	
	public ReciboPedagio(String identificacaoVeiculo, double valor, LocalDate data) {
		super();
		this.identificacaoVeiculo = identificacaoVeiculo;
		this.valor = valor;
		this.data = data;
	}

	public String getIdentificacaoVeiculo() {
		return identificacaoVeiculo;
	}

	public double getValor() {
		return valor;
	}

	public LocalDate getData() {
		return data;
	}

	@Override
	public String toString() {
		return "Recibo \n\nVeiculo: " 
				+ this.identificacaoVeiculo 
				+ "\n\nValor: " + this.valor;
	}
	
	
	
	
}
