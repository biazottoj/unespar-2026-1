package app;

import java.time.LocalDate;

import interfaces.Autenticavel;
import model.Caminhao;
import model.Carro;
import model.FornecedorParceiro;
import model.Moto;
import model.OperadorPedagio;
import model.ReciboPedagio;
import model.Veiculo;

public class Main {
	
	public static double processarPedagio(Veiculo veiculo) {
		System.out.println("O valor do pedágio é: " + 
	veiculo.calcularPedagio());
		return veiculo.calcularPedagio();
	}
	
	public static void main(String[] args) {
		FornecedorParceiro fornecedorParceiro = 
				new FornecedorParceiro("Sem Parar", "aaa1234");
		
		OperadorPedagio operador = 
				new OperadorPedagio("EPR", "casa123");
		
		
		Autenticavel[] usuarios = {fornecedorParceiro, 
				operador};
		
		for(Autenticavel a : usuarios) {
			System.out.println(a.autenticar("aaa1234"));
		}
	}
	
}
